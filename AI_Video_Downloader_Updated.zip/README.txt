
INSTRUCTIONS TO HOST:

1. Upload all these files to your public_html folder or any web hosting platform (Hostinger, Namecheap, etc).
2. If you're using Vercel/Netlify, drag and drop the folder to deploy.
3. For custom domain, point the domain to your hosting server.
4. You can edit index.html to insert AdSense code or affiliate banners.
5. Replace 'script.js' logic with real backend API for production use.
